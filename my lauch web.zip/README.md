# Vibe — Landing Page

A landing page for the Vibe chat app, ready to deploy on Render.

## Deploy to Render (5 minutes)

### Step 1 — Push to GitHub
1. Create a new repo on [github.com](https://github.com/new)
2. Run these commands in your terminal:

```bash
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vibe-landing.git
git push -u origin main
```

### Step 2 — Deploy on Render
1. Go to [render.com](https://render.com) and sign in
2. Click **New +** → **Static Site**
3. Connect your GitHub account and select the `vibe-landing` repo
4. Set these options:
   - **Name**: vibe-landing (or anything you like)
   - **Build Command**: *(leave blank)*
   - **Publish Directory**: `.`
5. Click **Create Static Site**

Render will give you a free URL like `https://vibe-landing.onrender.com` 🎉

### Step 3 — Add your real links
Open `index.html` and update the button `href` values:

| Button ID | What to put |
|---|---|
| `#ios-btn` | Your App Store URL |
| `#android-btn` | Your Google Play URL |
| `#download-btn` | Your direct download file URL |
| `#web-btn` | Your web app URL |

Search for `id="ios-btn"` etc. to find them quickly.

### Custom domain (optional)
In Render → your site → **Settings** → **Custom Domains**, add your domain and follow the DNS instructions.
